/*
   terdapat sebuah function createBoard memiliki 2 parameter rows dan columns untuk membuat multidimensi array jika rows 3 maka memiliki
   3 multidimensi array dan jika columns nya memiliki 4 maka 1 rows memiliki 4 data lihatlah hasil output yang di koment agar kalian mengerti 
  testcase number

*/

function createBoard(rows, columns) {
    
}
  
  console.log(createBoard(3, 4));
  /*
  [ 
      [ 1, 2, 3, 4 ], 
      [ 5, 6, 7, 8 ], 
      [ 9, 10, 11, 12 ] 
  ]
  */

 console.log(createBoard(4, 5));
 /*
 [
    [ 1, 2, 3, 4, 5 ],
    [ 6, 7, 8, 9, 10 ],
    [ 11, 12, 13, 14, 15 ],
    [ 16, 17, 18, 19, 20 ] 
 ]
 */
let arr = ['a', 'b', 'c', 'd', 'e'];
let obj = {
  name: 'hafidz',
  age: 21,
  address: {
    city: 'balikpapan',
    zipcode: 72111
  },
  hobbies: ['makan', 'nonton film']
};

for (let number in obj) {
  // console.log(obj);
}
// obj["tambah lagi"] = 'coba'
// console.log(obj["address"]["city"]);

// var car = {}
// car.color = "red"
// car.price = 20000000
// car.owner = {
// 	name: "Rama"
// }
// console.log(car)



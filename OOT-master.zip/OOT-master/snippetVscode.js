// {
// 	"FormEl": {
// 		"prefix": "formel",
// 		"body": [
// 			"<label for=\"$1\">$2</label>",
// 			"<input type=\"${3:text}\" name=\"$1\" id=\"$1\">"
// 		],
// 		"description": "Form Element"
// 	},
// 	// PHP Snippet
// 	"Debug Pre": {
// 		"prefix": "epre",
// 		"body": [
// 			"echo \"<pre>\".print_r(${1:\\$var},1).\"</pre>\";"
// 		],
// 		"description": "Debug with Pre"
// 	},
// 	"Console Log": {
// 		"prefix": "clog",
// 		"body": [
// 			"console.log($1);"
// 		],
// 		"description": "console log"
// 	},
// 	"Delimiter PHP": {
// 		"prefix": "php",
// 		"body": [
// 			"<?php $1 ?>"
// 		],
// 		"description": "delimiter php"
// 	},
// 	"Forr Loop": {
// 		"prefix": "forloop",
// 		"body": [
// 			"for (let i = $1; i ${2:<}; i++) {",
// 			"	${3:code}",
// 			"}"
// 		],
// 		"description": "for loop"
// 	}
// }
